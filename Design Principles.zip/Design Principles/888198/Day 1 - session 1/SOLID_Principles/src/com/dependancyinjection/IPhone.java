package com.dependancyinjection;

public interface IPhone {
	String getPhonePart1();
	double getPart1Cost();

}
