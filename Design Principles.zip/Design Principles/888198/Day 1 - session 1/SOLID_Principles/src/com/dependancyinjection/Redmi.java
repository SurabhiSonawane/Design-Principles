package com.dependancyinjection;

public class Redmi implements IPhone {

	@Override
	public String getPhonePart1() {
		// TODO Auto-generated method stub
		return "Redmi Display";
	}

	@Override
	public double getPart1Cost() {
		// TODO Auto-generated method stub
		return 500;
	}

}
