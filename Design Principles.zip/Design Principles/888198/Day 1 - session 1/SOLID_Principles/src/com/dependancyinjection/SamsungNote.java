package com.dependancyinjection;

public class SamsungNote implements IPhone {

	@Override
	public String getPhonePart1() {
		// TODO Auto-generated method stub
		return " Samsung Display";
	}

	@Override
	public double getPart1Cost() {
		// TODO Auto-generated method stub
		return 500;
	}

}
