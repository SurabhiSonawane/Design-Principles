package com.interfaces;

public interface AccessoryRepair {

	void ProcessAccessoryRepair(String accessoryType);
}
