package com.interfaces;

public interface POrder {
	void ProcessOrder(String modelName);

}
