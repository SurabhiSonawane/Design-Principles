package com.interfaces;

public interface PhoneRepair {
	
	void ProcessPhoneRepair(String modelName);

}
