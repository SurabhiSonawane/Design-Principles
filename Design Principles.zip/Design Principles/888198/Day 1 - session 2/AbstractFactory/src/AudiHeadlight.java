
public class AudiHeadlight extends Headlight {

	@Override
	public void print() {
		System.out.println("Audi Headlight");
		
	}

}
