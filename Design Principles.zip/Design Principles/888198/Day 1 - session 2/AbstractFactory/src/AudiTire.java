
public class AudiTire extends Tire {

	@Override
	public void print() {
		System.out.println("In Audi Tire");
		
	}

}
