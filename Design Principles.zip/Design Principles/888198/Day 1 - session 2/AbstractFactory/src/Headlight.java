
public abstract class Headlight {
	
	public abstract void print();

}
