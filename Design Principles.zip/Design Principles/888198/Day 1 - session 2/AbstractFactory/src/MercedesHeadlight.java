
public class MercedesHeadlight extends Headlight {

	@Override
	public void print() {
		System.out.println("Mercedes Headlight");
		
	}

}
