
public class MercedesTire extends Tire {

	@Override
	public void print() {
		System.out.println("In Mercedes Tire");
		
	}

}
