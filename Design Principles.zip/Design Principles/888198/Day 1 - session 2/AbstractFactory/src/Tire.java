
public abstract class Tire {
	public abstract void print();

}
