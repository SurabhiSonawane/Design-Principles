
public class Main {

	public static void main(String[] args) {
		
		
		DBConn object=DBConn.getInstance();
		object.caller();
		}
	}
