
public interface IUser {
void sendMessage(String name,String msg);
void receiveMessage(String msg);

}
