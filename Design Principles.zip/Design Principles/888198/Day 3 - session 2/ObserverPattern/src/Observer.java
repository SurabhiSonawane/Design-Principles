
public interface Observer {
	//public void update();

	void update(MessagePublisher msg);

}
